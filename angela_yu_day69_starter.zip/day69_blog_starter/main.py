from datetime import date
from functools import wraps

from flask import Flask, abort, flash, redirect, render_template, request, url_for
from flask_bootstrap import Bootstrap
from flask_ckeditor import CKEditor
from flask_login import LoginManager, UserMixin, current_user, login_required, login_user, logout_user
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship
from sqlalchemy import ForeignKey, Integer, String, Text
from werkzeug.security import check_password_hash, generate_password_hash

from forms import CommentForm, CreatePostForm, LoginForm, RegisterForm


class Base(DeclarativeBase):
    pass


app = Flask(__name__)
app.config['SECRET_KEY'] = 'change-this-in-a-real-project'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///posts.db'

db = SQLAlchemy(model_class=Base)
db.init_app(app)
Bootstrap(app)
ckeditor = CKEditor(app)

login_manager = LoginManager()
login_manager.init_app(app)


# TODO 1: egészítsd ki a User modellt, majd kapcsold a BlogPost és Comment modellekhez.
class User(UserMixin, db.Model):
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    email: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    password: Mapped[str] = mapped_column(String(255), nullable=False)
    name: Mapped[str] = mapped_column(String(100), nullable=False)


class BlogPost(db.Model):
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    title: Mapped[str] = mapped_column(String(250), unique=True, nullable=False)
    subtitle: Mapped[str] = mapped_column(String(250), nullable=False)
    date: Mapped[str] = mapped_column(String(250), nullable=False)
    body: Mapped[str] = mapped_column(Text, nullable=False)
    img_url: Mapped[str] = mapped_column(String(250), nullable=False)
    # TODO 2: author_id idegen kulcs és author relationship.


class Comment(db.Model):
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    text: Mapped[str] = mapped_column(Text, nullable=False)
    # TODO 3: author_id és post_id idegen kulcsok, valamint kapcsolatok.


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))


# TODO 4: készíts admin_only dekorátort az admin útvonalak védelméhez.
def admin_only(function):
    @wraps(function)
    def decorated_function(*args, **kwargs):
        abort(501)  # Cseréld le valódi jogosultság-ellenőrzésre.
    return decorated_function


@app.route('/')
def get_all_posts():
    posts = db.session.execute(db.select(BlogPost)).scalars().all()
    return render_template('index.html', all_posts=posts, current_user=current_user)


@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    # TODO 5: egyedi e-mail ellenőrzése, jelszó hashelése, mentés, login_user().
    if form.validate_on_submit():
        flash('TODO: implementáld a regisztrációt.')
    return render_template('register.html', form=form, current_user=current_user)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    # TODO 6: felhasználó lekérése, hash ellenőrzése, hibajelzések, login_user().
    if form.validate_on_submit():
        flash('TODO: implementáld a bejelentkezést.')
    return render_template('login.html', form=form, current_user=current_user)


@app.route('/logout')
def logout():
    # TODO 7: logout_user(), majd átirányítás.
    return redirect(url_for('get_all_posts'))


@app.route('/post/<int:post_id>', methods=['GET', 'POST'])
def show_post(post_id):
    requested_post = db.get_or_404(BlogPost, post_id)
    form = CommentForm()
    # TODO 8: csak bejelentkezett user kommentelhessen; mentsd a kommentet.
    return render_template('post.html', post=requested_post, form=form, current_user=current_user)


@app.route('/new-post', methods=['GET', 'POST'])
@login_required
def add_new_post():
    form = CreatePostForm()
    # TODO 9: készíts új BlogPost rekordot, és rendeld hozzá current_user-t szerzőként.
    return render_template('make-post.html', form=form, current_user=current_user)


@app.route('/edit-post/<int:post_id>', methods=['GET', 'POST'])
@login_required
def edit_post(post_id):
    post = db.get_or_404(BlogPost, post_id)
    form = CreatePostForm(obj=post)
    # TODO 10: valid beküldéskor frissítsd a rekordot.
    return render_template('make-post.html', form=form, is_edit=True, current_user=current_user)


@app.route('/delete/<int:post_id>')
@login_required
def delete_post(post_id):
    # TODO 11: admin-jogosultsággal töröld a bejegyzést.
    abort(501)


@app.route('/about')
def about():
    return render_template('about.html', current_user=current_user)


@app.route('/contact')
def contact():
    return render_template('contact.html', current_user=current_user)


with app.app_context():
    db.create_all()


if __name__ == '__main__':
    app.run(debug=True)
